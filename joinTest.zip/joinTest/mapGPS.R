library(dplyr)
library(ggmap)
library(mapproj)
air = read.csv("air.csv", header = TRUE)
map = read.csv("test.csv", header = TRUE)
map = map[,c(6,10,11)]
air$city = substr(air$IncineratorName, 1, 3)
names(map) = c("city", "gpsx", "gpsy")
map$city <- gsub("�x", "�O", map$city)
map = map[!is.na(map$gpsx),]
map = map[!is.na(map$gpsy),]
gps = map %>% group_by(city) %>%
  summarise(mean(gpsx), mean(gpsy))
names(gps) = c("city", "gpsx", "gpsy")
newData = left_join(air, gps, by = c("city"="city"))

map <- get_map(location = 'Taiwan', zoom = 8,
               language = "zh-TW")
ggmap(map) + geom_point(aes(x = gpsx, y = gpsy, size = NOx), data = newData)