
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)

shinyServer(function(input, output) {
  output$showDataName <- renderUI({
    h3(input$db)
  })
  
  output$distPlot <- renderPlot({
    # generate bins based on input$bins from ui.R
    if( input$db == "iris" )
    {
      dataShow = iris
    }
    else if( input$db == "cars" )
    {
      dataShow = cars
    }
    
    x    <- dataShow[,1]
    bins <- seq(min(x), max(x), length.out = input$bins + 1)

    # draw the histogram with the specified number of bins
    hist(x, breaks = bins, col = 'darkgray', border = 'white')

  })
  
  output$distText <- renderText({
    
    getData = paste0(input$text, "thanks")
  })
  
  output$dataset <- renderTable({
    if( input$db == "iris" )
    {
      dataShow = iris
    }
    else if( input$db == "cars" )
    {
      dataShow = cars
    }
  })
})
