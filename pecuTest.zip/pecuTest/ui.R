
# This is the user-interface definition of a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)

shinyUI(fluidPage(

  # Application title
  titlePanel("Old Faithful Geyser Data"),

  # Sidebar with a slider input for number of bins
  sidebarLayout(
    sidebarPanel(
      sliderInput("bins",
                  "Number of bins:",
                  min = 1,
                  max = 50,
                  value = 30),
      
      textInput("text", h3("Text input"), 
                value = "Enter text..."),
      
      selectInput("db", h3("select a dataset"),
                  choices = list("iris" = "iris", "cars" = "cars"), 
                  selected = "iris")
    ),

    # Show a plot of the generated distribution
    mainPanel(
      htmlOutput("showDataName"),
      plotOutput("distPlot"),
      textOutput("distText"),
      tableOutput("dataset")
    )
  )
))
